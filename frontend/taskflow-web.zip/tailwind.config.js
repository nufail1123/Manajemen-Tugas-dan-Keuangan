/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{vue,ts}'],
  theme: {
    extend: {
      // Tema neo-brutalist: persik + tinta ungu-gelap + ungu + kuning matahari + pink. Nama token tetap sama
      // dengan tema gelap sebelumnya, jadi semua komponen otomatis ikut berganti warna.
      colors: {
        ink: '#14101f', accent: '#ffd60a',
        background: '#fbeee3', surface: '#fbeee3',
        'surface-container-lowest': '#fff8f1', 'surface-container-low': '#ffffff', 'surface-container': '#f4e4d7',
        'surface-container-high': '#ecd9c9', 'surface-container-highest': '#e0c9b5', 'surface-variant': '#e0c9b5', 'surface-bright': '#ffffff',
        'on-background': '#14101f', 'on-surface': '#14101f', 'on-surface-variant': '#54485f',
        outline: '#85798f', 'outline-variant': '#d3c3b6',
        primary: '#6a2cf0', 'on-primary': '#ffffff', 'primary-container': '#6a2cf0', 'on-primary-container': '#ffffff',
        'primary-fixed': '#5316c9', 'primary-fixed-dim': '#c3a9ff',
        secondary: '#0b7a52', 'on-secondary': '#ffffff', 'secondary-container': '#0b7a52', 'on-secondary-container': '#ffffff',
        tertiary: '#c2185b', 'tertiary-container': '#ff7eb0',
        error: '#d11a1a', 'on-error': '#ffffff', 'error-container': '#d11a1a', 'on-error-container': '#ffffff',
      },
      borderRadius: { none: '0', sm: '0', DEFAULT: '0', md: '0', lg: '0', xl: '0', '2xl': '0', full: '9999px' },
      // Bayangan "keras" tanpa blur. shadow-sm/md/lg/xl/2xl yang sudah dipakai di komponen otomatis jadi gaya ini.
      boxShadow: {
        'hard-sm': '2px 2px 0 0 #14101f', hard: '4px 4px 0 0 #14101f', 'hard-lg': '6px 6px 0 0 #14101f', 'hard-xl': '8px 8px 0 0 #14101f',
        sm: '3px 3px 0 0 #14101f', DEFAULT: '3px 3px 0 0 #14101f', md: '4px 4px 0 0 #14101f', lg: '6px 6px 0 0 #14101f',
        xl: '8px 8px 0 0 #14101f', '2xl': '8px 8px 0 0 #14101f', inner: 'none',
      },
      keyframes: {
        rise: { from: { opacity: '0', transform: 'translateY(18px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        fade: { from: { opacity: '0' }, to: { opacity: '1' } },
        pop: { from: { opacity: '0', transform: 'translateY(-6px) scale(.96)' }, to: { opacity: '1', transform: 'translateY(0) scale(1)' } },
        'pop-center': { from: { opacity: '0', transform: 'translate(-50%,-46%) scale(.94)' }, to: { opacity: '1', transform: 'translate(-50%,-50%) scale(1)' } },
        marquee: { from: { transform: 'translateX(0)' }, to: { transform: 'translateX(-50%)' } },
        blink: { '0%,49%': { opacity: '1' }, '50%,100%': { opacity: '0' } },
        'grow-x': { from: { transform: 'scaleX(0)' }, to: { transform: 'scaleX(1)' } },
        'reveal-x': { from: { clipPath: 'inset(0 100% 0 0)' }, to: { clipPath: 'inset(0 0 0 0)' } },
        float: { '0%,100%': { transform: 'translateY(0) rotate(-4deg)' }, '50%': { transform: 'translateY(-14px) rotate(4deg)' } },
        wiggle: { '0%,100%': { transform: 'rotate(0)' }, '25%': { transform: 'rotate(-10deg)' }, '75%': { transform: 'rotate(10deg)' } },
      },
      animation: {
        rise: 'rise .6s cubic-bezier(.2,.8,.2,1) backwards', fade: 'fade .2s ease-out', pop: 'pop .18s cubic-bezier(.2,.9,.3,1.2)',
        'pop-center': 'pop-center .24s cubic-bezier(.2,.9,.3,1.2)', marquee: 'marquee 28s linear infinite',
        blink: 'blink 1s steps(1) infinite', 'grow-x': 'grow-x .8s cubic-bezier(.2,.8,.2,1) .2s backwards',
        'reveal-x': 'reveal-x 1.1s cubic-bezier(.65,0,.35,1) .3s backwards', float: 'float 6s ease-in-out infinite',
        'float-slow': 'float 9s ease-in-out infinite reverse', wiggle: 'wiggle .5s ease-in-out',
      },
      spacing: {
        margin: '1rem', 'margin-md': '1.5rem', 'margin-lg': '2rem',
        'space-xs': '0.25rem', 'space-sm': '0.5rem', 'space-md': '1rem', 'space-lg': '1.5rem', 'space-xl': '2rem',
        gutter: '1rem', 'gutter-lg': '1.5rem',
      },
      fontFamily: {
        'display-lg': ['Archivo Variable', 'Geist Variable', 'sans-serif'], 'headline-xl': ['Archivo Variable', 'Geist Variable', 'sans-serif'],
        'headline-md': ['Archivo Variable', 'Geist Variable', 'sans-serif'], 'headline-sm': ['Geist Variable', 'sans-serif'],
        'body-lg': ['Geist Variable', 'sans-serif'], 'body-md': ['Geist Variable', 'sans-serif'],
        'body-sm': ['Geist Variable', 'sans-serif'],
        'label-md': ['JetBrains Mono Variable', 'monospace'], 'label-sm': ['JetBrains Mono Variable', 'monospace'],
      },
      fontSize: {
        'display-lg': ['3.5rem', { lineHeight: '4rem', letterSpacing: '-0.03em', fontWeight: '600' }],
        'headline-xl': ['2.25rem', { lineHeight: '2.75rem', letterSpacing: '-0.025em', fontWeight: '600' }],
        'headline-md': ['1.5rem', { lineHeight: '2rem', letterSpacing: '-0.015em', fontWeight: '500' }],
        'headline-sm': ['1.125rem', { lineHeight: '1.5rem', letterSpacing: '-0.01em', fontWeight: '500' }],
        'body-lg': ['1rem', { lineHeight: '1.5rem', fontWeight: '400' }],
        'body-md': ['0.875rem', { lineHeight: '1.25rem', fontWeight: '400' }],
        'body-sm': ['0.75rem', { lineHeight: '1rem', fontWeight: '400' }],
        'label-md': ['0.8125rem', { lineHeight: '1rem', letterSpacing: '0.02em', fontWeight: '500' }],
        'label-sm': ['0.6875rem', { lineHeight: '0.875rem', letterSpacing: '0.04em', fontWeight: '500' }],
      },
    },
  },
}
